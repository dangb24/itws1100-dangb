the inclass files are given to the class in a zip file

the completed files are comppleted and uncommented and may be used to demontrate final product - They are READ ONLY

The stepbystep files are commented versions of the inclass files and can be run step nby step in coordination with the slides

upon start of class the step by step are commentedas you progress uncommenting, 
the final are the same as the completed files

upon completion re-comment the code in the step-bystep files or unzip the stepbystep zip
